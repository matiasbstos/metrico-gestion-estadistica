import React, { useState, useEffect, useMemo, Component } from 'react';
import PanelKPIs from './dashboard/PanelKPIs';
import FiltrosGlobales from './dashboard/FiltrosGlobales';
import GraficoDinamico from './dashboard/GraficoDinamico';
import AnalisisEquiposTurno from './dashboard/AnalisisEquiposTurno';
import CurvaDemanda from './dashboard/CurvaDemanda';
import AnalisisSociodemografico from './dashboard/AnalisisSociodemografico';
import TablaTiemposEspera from './dashboard/TablaTiemposEspera';
import AnalisisProfesionales from './dashboard/AnalisisProfesionales';
import RankingProfesionales from './dashboard/RankingProfesionales';
import DataGridTurnos from './dashboard/DataGridTurnos';
import GestionDatos from './dashboard/GestionDatos';
import ReportesModule from './dashboard/ReportesModule';
import MatrizCruzada from './dashboard/MatrizCruzada';
import AuditLog from './dashboard/AuditLog';
import Login from './Login';
import { 
  Clock, Users, UserCheck, AlertTriangle, Activity, ArrowRight, 
  FileSpreadsheet, Database, BarChart2, Trash2, Edit, Edit2,
  CheckCircle, XCircle, Filter, PieChart as PieChartIcon, 
  BarChart as BarChartIcon, TrendingUp, X, Cloud, CloudUpload, CloudOff,
  Calendar, Layers, Save, TrendingDown, ArrowUpRight, ArrowDownRight,
  HeartPulse, Shield, Globe, Building2, MapPin, Search, Zap, UserPlus, Eraser, Lock
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell, 
  LineChart, Line, ResponsiveContainer, CartesianGrid, ComposedChart, Area, AreaChart
} from 'recharts';

import { auth, db, appId } from '../config/firebase';
import { collection, doc, writeBatch, updateDoc, deleteDoc } from 'firebase/firestore';
import { useMetricoData } from '../hooks/useMetricoData';
import { useMetricoAnalytics } from '../hooks/useMetricoAnalytics';
import { useMetricoDemanda } from '../hooks/useMetricoDemanda';
import { useMetricoProfesionales } from '../hooks/useMetricoProfesionales';
import { COLORS, DOC_COLORS, AGE_RANGES, METRIC_LABELS } from '../config/constants';

// Colores Institucionales



const DashboardContent = () => {
  const [activeTab, setActiveTab] = useState('resumen');
  const [notification, setNotification] = useState(null);
  const [pendingUpload, setPendingUpload] = useState(null);
  const [editModal, setEditModal] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [centroActivo, setCentroActivo] = useState(localStorage.getItem('metrico_centro') || 'SAR Elsa Romo Aravena');
  
  const [manualForm, setManualForm] = useState({
    fechaInicio: '', fechaFin: '', horario: '08:00 - 20:00',
    c1: 0, c2: 0, c3: 0, c3_z518: 0, c4: 0, c5: 0, altasAdmin: 0, totalPacientes: 0
  });

  const today = new Date();
  const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1).toISOString().split('T')[0];
  const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).toISOString().split('T')[0];
  
  const [filtroFechaInicio, setFiltroFechaInicio] = useState(firstDayOfMonth);
  const [filtroFechaFin, setFiltroFechaFin] = useState(lastDayOfMonth);
  const [modoComparativo, setModoComparativo] = useState(false);
  const [filtroFechaInicioB, setFiltroFechaInicioB] = useState('');
  const [filtroFechaFinB, setFiltroFechaFinB] = useState('');
  
  const [demandaFechaInicio, setDemandaFechaInicio] = useState(firstDayOfMonth);
  const [demandaFechaFin, setDemandaFechaFin] = useState(lastDayOfMonth);
  const [demandaViewMode, setDemandaViewMode] = useState('total');

  const [profFechaInicio, setProfFechaInicio] = useState(firstDayOfMonth);
  const [profFechaFin, setProfFechaFin] = useState(lastDayOfMonth);
  const [docsToCompare, setDocsToCompare] = useState([]);
  const [searchDoctor, setSearchDoctor] = useState('');
  const [profesionalesChartType, setProfesionalesChartType] = useState('ambos');

  const [tipoGrafico, setTipoGrafico] = useState('barras');
  const [metricasGrafico, setMetricasGrafico] = useState(['totalPacientes']);
  const [filtroVariables, setFiltroVariables] = useState('');
  const [paginaTurnos, setPaginaTurnos] = useState(1);
  const turnosPorPagina = 10;

  const [filtrosGlobales, setFiltrosGlobales] = useState({ sexo: 'TODOS', prevision: 'TODOS', edad: 'TODOS', establecimiento: 'TODOS' });

  const { user, userProfile, loading, syncStatus, setSyncStatus, setLoading, pacientesDB, turnosDB } = useMetricoData();

  useEffect(() => {
    const loadSheetJS = () => {
      if (!document.getElementById('sheetjs-script')) {
        const script = document.createElement('script');
        script.id = 'sheetjs-script';
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
        document.head.appendChild(script);
      }
    };
    loadSheetJS();
  }, []);

  useEffect(() => {
    localStorage.setItem('metrico_centro', centroActivo);
  }, [centroActivo]);

  useEffect(() => {
    setDemandaFechaInicio(filtroFechaInicio);
    setDemandaFechaFin(filtroFechaFin);
    setProfFechaInicio(filtroFechaInicio);
    setProfFechaFin(filtroFechaFin);
  }, [filtroFechaInicio, filtroFechaFin]);

  useEffect(() => {
    if (demandaViewMode === 'periodos' && !modoComparativo) setDemandaViewMode('total');
    if (demandaViewMode === 'doctores' && docsToCompare.length === 0) setDemandaViewMode('total');
  }, [modoComparativo, docsToCompare, demandaViewMode]);

  const showNotif = (msg, type = 'info') => {
    setNotification({ msg: String(msg), type });
    setTimeout(() => setNotification(null), 5000);
  };

  const perc = (val, tot) => tot > 0 ? ((val / tot) * 100).toFixed(1) : 0;

  const formatTime = (minutes) => {
    if (isNaN(minutes) || minutes < 0 || minutes === null) return '-';
    if (minutes < 60) return `${Math.round(minutes)} min`;
    const h = Math.floor(minutes / 60); const m = Math.round(minutes % 60);
    return `${h}h ${m}m`;
  };

  const applyDatePreset = (preset) => {
    const today = new Date();
    const formatDate = (d) => isNaN(d.getTime()) ? '' : d.toISOString().split('T')[0];
    let startA, endA, startB, endB;
    if (preset === 'mes') {
      startA = new Date(today.getFullYear(), today.getMonth(), 1);
      endA = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      startB = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      endB = new Date(today.getFullYear(), today.getMonth(), 0);
    } else if (preset === 'semana') {
      const firstDay = new Date(today.setDate(today.getDate() - today.getDay() + 1));
      const lastDay = new Date(today.setDate(today.getDate() - today.getDay() + 7));
      startA = firstDay; endA = lastDay;
      startB = new Date(firstDay.getTime() - 7 * 24 * 60 * 60 * 1000);
      endB = new Date(lastDay.getTime() - 7 * 24 * 60 * 60 * 1000);
    } else if (preset === 'dia') {
      startA = endA = new Date();
      startB = endB = new Date(today.getTime() - 24 * 60 * 60 * 1000);
    }
    setFiltroFechaInicio(formatDate(startA));
    setFiltroFechaFin(formatDate(endA));
    if(modoComparativo) {
      setFiltroFechaInicioB(formatDate(startB));
      setFiltroFechaFinB(formatDate(endB));
    }
  };

  const { turnosFiltrados, pacientesFiltrados, demografiaStats, promediosGlobales, metricsByCategory, statsKPI, rankingCentros } = useMetricoAnalytics(pacientesDB, turnosDB, filtroFechaInicio, filtroFechaFin, filtrosGlobales);
  const { turnosDemanda, pacientesDemanda, peakHoursData } = useMetricoDemanda(pacientesDB, turnosDB, demandaFechaInicio, demandaFechaFin, modoComparativo, filtroFechaInicioB, filtroFechaFinB, docsToCompare);
  const { turnosProf, pacientesProf, metricsByDoctor, filteredMetricsByDoctor, dailyDoctorData } = useMetricoProfesionales(pacientesDB, turnosDB, profFechaInicio, profFechaFin, docsToCompare, searchDoctor);

  const toggleDocToCompare = (docName) => {
    setDocsToCompare(prev => prev.includes(docName) ? prev.filter(d => d !== docName) : [...prev, docName]);
  };
  const clearDocComparison = () => setDocsToCompare([]);

  const totalPaginasTurnos = Math.ceil(turnosDB.length / turnosPorPagina) || 1;
  const turnosPaginados = useMemo(() => {
    return turnosDB.slice((paginaTurnos - 1) * turnosPorPagina, paginaTurnos * turnosPorPagina);
  }, [turnosDB, paginaTurnos]);

  const saveEditedTurno = async () => {
    if (!editModal || !user || !db) return;
    if (userProfile?.rol !== 'global') {
      showNotif('No tienes permisos para editar turnos.', 'error');
      return;
    }
    setLoading(true); setSyncStatus('syncing');
    try {
      const horasTurno = String(editModal.horario || '').includes("17:00") ? 15 : 12;
      const ratio = Number(editModal.totalPacientes) / horasTurno;
      const ref = doc(db, 'artifacts', appId, 'public', 'data', 'turnos', editModal.id);
      
      const auditLog = {
        fecha: Date.now(),
        accion: 'Edición',
        detalles: `Turno ${editModal.id} editado (${editModal.totalPacientes} pacientes).`,
        centro: centroActivo,
        usuario: user?.email || 'Anónimo'
      };

      const batch = writeBatch(db);
      batch.update(ref, {
        totalPacientes: Number(editModal.totalPacientes), altasAdmin: Number(editModal.altasAdmin),
        c1: Number(editModal.c1), c2: Number(editModal.c2), c3: Number(editModal.c3), 
        c3_z518: Number(editModal.c3_z518 || 0), c4: Number(editModal.c4), c5: Number(editModal.c5), 
        horario: editModal.horario, equipoTurno: editModal.equipoTurno || 'Sin Asignar', pacientesPorHora: ratio
      });
      batch.set(doc(collection(db, 'artifacts', appId, 'public', 'data', 'audit_logs')), auditLog);
      await batch.commit();

      showNotif('Turno actualizado correctamente.', 'success');
      setEditModal(null);
    } catch(e) { showNotif('Error al guardar cambios', 'error'); }
    setLoading(false); setSyncStatus('synced');
  };

  const executeDeleteTurno = async (turno) => {
    if (!user || !db) return;
    if (userProfile?.rol !== 'global') {
      showNotif('No tienes permisos para eliminar turnos.', 'error');
      return;
    }
    setLoading(true); setSyncStatus('syncing');
    try {
      const auditLog = {
        fecha: Date.now(),
        accion: 'Eliminación',
        detalles: `Turno ${turno.id} eliminado.`,
        centro: centroActivo,
        usuario: user?.email || 'Anónimo'
      };
      await writeBatch(db).set(doc(collection(db, 'artifacts', appId, 'public', 'data', 'audit_logs')), auditLog).commit();
      
      await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'turnos', turno.id));
      if (turno.tipo === 'Masiva' && turno.loteId) {
        const pacientesAsociados = pacientesDB.filter(p => p.loteId === turno.loteId);
        for (let i = 0; i < pacientesAsociados.length; i += 400) {
            const batch = writeBatch(db);
            pacientesAsociados.slice(i, i + 400).forEach(p => {
                const pRef = doc(db, 'artifacts', appId, 'public', 'data', 'pacientes_urgencia', p.id);
                batch.delete(pRef);
            });
            await batch.commit();
        }
      }
      setNotification({ message: 'Lote eliminado.', type: 'success' });
    } catch (e) { setNotification({ message: 'Hubo un problema al limpiar pacientes.', type: 'warning' }); }
    setDeleteConfirm(null);
    setLoading(false); setSyncStatus('synced');
  };

  // Variables para GraficoDinamico
  const dynamicMetricKeys = {
      sexo: [{ label: 'Mujeres', value: 'sexo_f', color: '#ec4899' }, { label: 'Hombres', value: 'sexo_m', color: '#3b82f6' }],
      edad: [
        { label: 'Niños (0-14)', value: 'edad_0_14', color: '#f59e0b' },
        { label: 'Jóvenes (15-29)', value: 'edad_15_29', color: '#84cc16' },
        { label: 'Adultos (30-59)', value: 'edad_30_59', color: '#14b8a6' },
        { label: 'Mayor (60+)', value: 'edad_60_plus', color: '#6366f1' }
      ],
      prev: [{ label: 'Fonasa', value: 'prev_fonasa', color: '#10b981' }, { label: 'Isapre', value: 'prev_isapre', color: '#0ea5e9' }],
      com: [{ label: 'Melipilla', value: 'com_melipilla', color: '#8b5cf6' }, { label: 'Otras Comunas', value: 'com_otras', color: '#f43f5e' }],
      nac: [{ label: 'Chilenos', value: 'nac_chilena', color: '#ef4444' }, { label: 'Extranjeros', value: 'nac_extranjera', color: '#06b6d4' }],
      est: [
        { label: 'CESFAM Florencia', value: 'est_florencia', color: '#8b5cf6' },
        { label: 'CESFAM Boris', value: 'est_boris', color: '#d946ef' },
        { label: 'CESFAM Elgueta', value: 'est_elgueta', color: '#f43f5e' },
        { label: 'Otros Centros', value: 'est_otros', color: '#94a3b8' }
      ]
  };

  const getColorForMetric = (metricKey) => {
      if (METRIC_LABELS[metricKey]) return COLORS[metricKey] || '#94a3b8';
      for (const group in dynamicMetricKeys) {
        const found = dynamicMetricKeys[group].find(m => m.value === metricKey);
        if (found) return found.color;
      }
      return '#cbd5e1';
  };

  const formatMetricName = (metricKey) => {
      if (METRIC_LABELS[metricKey]) return METRIC_LABELS[metricKey];
      for (const group in dynamicMetricKeys) {
        const found = dynamicMetricKeys[group].find(m => m.value === metricKey);
        if (found) return found.label;
      }
      return metricKey;
  };

  const handleGraphToggleChange = (metricValue) => {
    setMetricasGrafico(prev => {
      if (prev.includes(metricValue)) return prev.filter(m => m !== metricValue);
      return [...prev, metricValue];
    });
  };

  const renderCheckbox = (metric) => (
    <label key={metric.value} className="flex items-center gap-2 cursor-pointer text-xs group">
      <div className="relative flex items-center justify-center">
        <input 
          type="checkbox" 
          checked={metricasGrafico.includes(metric.value)}
          onChange={() => handleGraphToggleChange(metric.value)}
          className="sr-only"
        />
        <div className={`w-4 h-4 rounded transition border ${metricasGrafico.includes(metric.value) ? 'border-transparent' : 'border-slate-300 group-hover:border-slate-400'}`} style={{ backgroundColor: metricasGrafico.includes(metric.value) ? metric.color : 'transparent' }}>
          {metricasGrafico.includes(metric.value) && <CheckCircle className="w-3.5 h-3.5 text-white absolute top-0.5 left-0.5" />}
        </div>
      </div>
      <span className={metricasGrafico.includes(metric.value) ? 'font-bold text-slate-700' : 'text-slate-500'}>{metric.label}</span>
    </label>
  );

  const compareChartData = useMemo(() => {
    if (!modoComparativo) return [];
    let currentTotal = turnosFiltrados.reduce((acc, t) => acc + Number(t.totalPacientes || 0), 0);
    const turnosB = turnosDB.filter(t => t.fechaInicio >= filtroFechaInicioB && t.fechaFin <= filtroFechaFinB);
    let prevTotal = turnosB.reduce((acc, t) => acc + Number(t.totalPacientes || 0), 0);
    return [{ name: 'Volumen Total', 'Periodo A': currentTotal, 'Periodo B': prevTotal }];
  }, [turnosFiltrados, turnosDB, filtroFechaInicioB, filtroFechaFinB, modoComparativo]);

  const chartData = useMemo(() => {
    if (modoComparativo) return [];
    return turnosFiltrados.slice().reverse().map(t => {
      const row = { name: t.fechaInicio === t.fechaFin ? t.fechaInicio : `${t.fechaInicio} - ${t.fechaFin}` };
      
      metricasGrafico.forEach(m => {
        if (METRIC_LABELS[m]) {
          row[m] = Number(t[m] || 0);
        } else {
          const pacs = pacientesFiltrados.filter(p => p.loteId === t.loteId);
          if (m === 'sexo_f') row[m] = pacs.filter(p => String(p.sexo).toUpperCase().includes('F')).length;
          else if (m === 'sexo_m') row[m] = pacs.filter(p => String(p.sexo).toUpperCase().includes('M')).length;
          else if (m === 'edad_0_14') row[m] = pacs.filter(p => p.edad !== null && p.edad >= 0 && p.edad <= 14).length;
          else if (m === 'edad_15_29') row[m] = pacs.filter(p => p.edad !== null && p.edad >= 15 && p.edad <= 29).length;
          else if (m === 'edad_30_59') row[m] = pacs.filter(p => p.edad !== null && p.edad >= 30 && p.edad <= 59).length;
          else if (m === 'edad_60_plus') row[m] = pacs.filter(p => p.edad !== null && p.edad >= 60).length;
          else if (m === 'prev_fonasa') row[m] = pacs.filter(p => String(p.prevision).toUpperCase().includes('FONASA')).length;
          else if (m === 'prev_isapre') row[m] = pacs.filter(p => String(p.prevision).toUpperCase().includes('ISAPRE')).length;
          else if (m === 'com_melipilla') row[m] = pacs.filter(p => String(p.comuna).toUpperCase() === 'MELIPILLA').length;
          else if (m === 'com_otras') row[m] = pacs.filter(p => p.comuna && String(p.comuna).toUpperCase() !== 'MELIPILLA').length;
          else if (m === 'nac_chilena') row[m] = pacs.filter(p => String(p.nacionalidad).toUpperCase().includes('CHILEN')).length;
          else if (m === 'nac_extranjera') row[m] = pacs.filter(p => p.nacionalidad && !String(p.nacionalidad).toUpperCase().includes('CHILEN')).length;
          else if (m === 'est_florencia') row[m] = pacs.filter(p => String(p.establecimiento).toUpperCase().includes('FLORENCIA')).length;
          else if (m === 'est_boris') row[m] = pacs.filter(p => String(p.establecimiento).toUpperCase().includes('BORIS')).length;
          else if (m === 'est_elgueta') row[m] = pacs.filter(p => String(p.establecimiento).toUpperCase().includes('ELGUETA')).length;
          else if (m === 'est_otros') row[m] = pacs.filter(p => p.establecimiento && !String(p.establecimiento).toUpperCase().match(/FLORENCIA|BORIS|ELGUETA/)).length;
        }
      });

      return row;
    });
  }, [turnosFiltrados, pacientesFiltrados, metricasGrafico, modoComparativo]);

  const pieData = useMemo(() => {
    if (modoComparativo) return [];
    return ['c1', 'c2', 'c3', 'c3_z518', 'c4', 'c5'].map(c => ({
      name: c === 'c3_z518' ? 'C3 (Lesiones)' : c.toUpperCase(),
      value: turnosFiltrados.reduce((acc, t) => acc + Number(t[c] || 0), 0)
    })).filter(d => d.value > 0);
  }, [turnosFiltrados, modoComparativo]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8 font-sans">
        <div className="bg-white p-8 rounded-xl shadow-xl max-w-sm w-full text-center border border-slate-100">
          <Activity className="w-12 h-12 text-blue-600 animate-pulse mx-auto mb-4" />
          <h2 className="text-xl font-bold text-slate-800 mb-2">Conectando a METRICO</h2>
          <p className="text-sm text-slate-500 mb-6">Sincronizando registros encriptados...</p>
          <div className="w-full bg-slate-100 rounded-full h-2 mb-2"><div className="bg-blue-600 h-2 rounded-full w-2/3 animate-pulse"></div></div>
          <p className="text-[10px] text-slate-400 font-mono">Buscando actualizaciones ({syncStatus})</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  const handleLogout = () => {
    import('firebase/auth').then(({ signOut }) => {
      signOut(auth);
    });
  };

  const handlePasswordResetRequest = () => {
    if (!user.email) return;
    import('firebase/auth').then(({ sendPasswordResetEmail }) => {
      sendPasswordResetEmail(auth, user.email).then(() => {
        showNotif('Se ha enviado un correo para restablecer tu contraseña.', 'success');
      }).catch(() => {
        showNotif('Hubo un error al enviar el correo.', 'error');
      });
    });
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-50 font-sans text-slate-800">
      {/* COLUMNA IZQUIERDA: SIDEBAR FIJO */}
      <aside className="w-64 h-full bg-slate-900 text-white flex flex-col justify-between flex-shrink-0 z-10 shadow-xl">
        <div>
          <div className="p-6 flex items-center gap-3">
            <Activity className="w-8 h-8 text-sky-500" />
            <div>
              <h1 className="font-black text-lg tracking-tight leading-none">MÉTRICO</h1>
              <p className="text-[10px] text-slate-400 font-medium mb-2">Clínico Predictivo</p>
              <select 
                className="bg-slate-800 text-sky-400 text-xs p-1 rounded border border-slate-700 outline-none w-full font-bold cursor-pointer"
                value={centroActivo} 
                onChange={e => setCentroActivo(e.target.value)}
              >
                <option value="SAR Elsa Romo Aravena">SAR Elsa Romo Aravena</option>
                <option value="CESFAM Florencia">CESFAM Florencia</option>
                <option value="CESFAM Boris Soler">CESFAM Boris Soler</option>
                <option value="CESFAM Elgueta">CESFAM Elgueta</option>
              </select>
            </div>
          </div>
          
          <div className="px-6 mb-4">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span className="text-xs font-bold text-emerald-400">Sistema En Línea</span>
            </div>
            {syncStatus === 'synced' && <p className="text-[10px] text-slate-500">Último guardado: hace unos segundos</p>}
            {syncStatus === 'syncing' && <p className="text-[10px] text-sky-400">Guardando cambios...</p>}
          </div>

          <nav className="mt-2 flex flex-col gap-1 px-3">
            <button 
              onClick={() => setActiveTab('resumen')}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg font-bold text-sm shadow-md transition-colors ${activeTab === 'resumen' ? 'bg-sky-500 text-white' : 'bg-transparent text-slate-400 hover:text-white hover:bg-slate-800'}`}>
              <BarChart2 className="w-4 h-4" /> Inicio
            </button>
            <button 
              onClick={() => setActiveTab('reportes')}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg font-medium text-sm transition-colors ${activeTab === 'reportes' ? 'bg-sky-500 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}>
              <FileSpreadsheet className="w-4 h-4" /> Reporte
            </button>
            {userProfile?.rol === 'global' && (
              <>
                <button 
                  onClick={() => setActiveTab('data')} 
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg font-medium text-sm transition-colors ${activeTab === 'data' ? 'bg-sky-500 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}>
                  <Database className="w-4 h-4" /> Gestión de Datos
                </button>
                <button 
                  onClick={() => setActiveTab('auditoria')} 
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg font-medium text-sm transition-colors ${activeTab === 'auditoria' ? 'bg-sky-500 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}>
                  <Shield className="w-4 h-4" /> Auditoría
                </button>
              </>
            )}
          </nav>
        </div>
        <div className="p-4 border-t border-slate-800">
          <div className="mb-4 px-2">
            <p className="text-xs font-bold text-slate-300 truncate" title={user.email}>{user.email}</p>
            <p className="text-[10px] text-sky-400 font-medium uppercase mt-0.5">{userProfile?.rol === 'global' ? 'Administrador Global' : 'Usuario Local'}</p>
          </div>
          <button onClick={handlePasswordResetRequest} className="flex items-center gap-3 px-4 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg font-medium text-xs transition-colors w-full mb-1">
            <Lock className="w-3.5 h-3.5" /> Cambiar Clave
          </button>
          <button onClick={handleLogout} className="flex items-center gap-3 px-4 py-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg font-medium text-xs transition-colors w-full">
            <XCircle className="w-3.5 h-3.5" /> Cerrar Sesión
          </button>
        </div>
      </aside>

      {/* MODALES Y OVERLAYS */}
      {syncStatus === 'syncing' && (
        <div className="fixed inset-0 z-[100] bg-slate-900/70 backdrop-blur-sm flex flex-col justify-center items-center animate-fade-in">
          <div className="bg-white/10 p-8 rounded-3xl backdrop-blur-md border border-white/20 shadow-2xl flex flex-col items-center max-w-sm text-center">
            <HeartPulse className="w-16 h-16 text-sky-400 animate-bounce mb-4" />
            <h3 className="text-xl font-black text-white tracking-widest uppercase">Actualizando</h3>
            <p className="text-sky-200 text-sm mt-2 font-medium">Sincronizando registros encriptados...</p>
            <div className="w-32 bg-slate-800/50 rounded-full h-1 mt-6 overflow-hidden relative">
              <div className="absolute top-0 left-0 h-full bg-sky-400 w-1/2 animate-[pulse_1s_ease-in-out_infinite] blur-[1px]"></div>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in p-4">
          <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-white/50">
            <div className="bg-gradient-to-r from-rose-500 to-rose-700 text-white p-5 flex justify-between items-center shadow-sm">
              <h3 className="font-black tracking-wide flex items-center gap-2"><Trash2 className="w-5 h-5"/> Eliminar Lote</h3>
              <button onClick={() => setDeleteConfirm(null)} className="hover:bg-rose-600/50 p-1.5 rounded-lg transition-colors"><X className="w-5 h-5"/></button>
            </div>
            <div className="p-6">
              <div className="bg-rose-50 border border-rose-100 p-4 rounded-xl mb-6">
                <p className="text-rose-800 text-sm font-medium leading-relaxed">¿Estás seguro que deseas eliminar este registro de forma permanente? <br/><br/>Si es una carga masiva, se borrarán <span className="font-bold">todos los pacientes</span> asociados a este lote.</p>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setDeleteConfirm(null)} className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl hover:bg-slate-50 hover:text-slate-900 font-bold transition-all shadow-sm">Cancelar</button>
                <button onClick={() => executeDeleteTurno(deleteConfirm)} className="flex-1 px-4 py-3 bg-rose-500 text-white rounded-xl hover:bg-rose-600 font-bold transition-all shadow-md shadow-rose-500/20">Sí, Eliminar Registro</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {editModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in p-4">
          <div className="bg-white/95 backdrop-blur-xl rounded-2xl shadow-2xl max-w-md w-full overflow-hidden border border-white/50">
            <div className="bg-gradient-to-r from-indigo-600 to-indigo-800 text-white p-5 flex justify-between items-center shadow-sm">
              <h3 className="font-black tracking-wide flex items-center gap-2"><Edit className="w-5 h-5"/> Editar Registro</h3>
              <button onClick={() => setEditModal(null)} className="hover:bg-indigo-600/50 p-1.5 rounded-lg transition-colors"><X className="w-5 h-5"/></button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-sm text-slate-500">Fecha del turno: <span className="font-bold text-slate-700">{editModal.fechaInicio}</span></p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold mb-1 text-slate-600">Horario</label>
                  <select className="w-full p-2 border rounded bg-slate-50" value={editModal.horario} onChange={e => setEditModal({...editModal, horario: e.target.value})}>
                    <option>08:00 - 20:00 (Diurno)</option><option>20:00 - 08:00 (Nocturno)</option><option>17:00 - 08:00 (Semana Largo)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold mb-1 text-slate-600">Equipo de Turno</label>
                  <select className="w-full p-2 border rounded bg-slate-50 text-indigo-700 font-bold" value={editModal.equipoTurno || 'Sin Asignar'} onChange={e => setEditModal({...editModal, equipoTurno: e.target.value})}>
                    <option value="Turno 1">Turno 1</option>
                    <option value="Turno 2">Turno 2</option>
                    <option value="Turno 3">Turno 3</option>
                    <option value="Sin Asignar">Sin Asignar</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="block text-[10px] font-bold mb-1 text-slate-500 uppercase">Total Pacientes</label><input type="number" className="w-full p-2 border rounded font-bold text-indigo-600" value={editModal.totalPacientes} onChange={e => setEditModal({...editModal, totalPacientes: e.target.value})} /></div>
                <div><label className="block text-[10px] font-bold mb-1 text-rose-500 uppercase">Altas Admin</label><input type="number" className="w-full p-2 border rounded font-bold text-rose-600" value={editModal.altasAdmin} onChange={e => setEditModal({...editModal, altasAdmin: e.target.value})} /></div>
              </div>
              <div className="grid grid-cols-6 gap-2 pt-2 border-t">
                {['c1', 'c2', 'c3', 'c3_z518', 'c4', 'c5'].map(cat => (
                  <div key={cat}>
                    <label className="block text-[10px] font-bold uppercase mb-1 whitespace-nowrap text-center" style={{color: COLORS[cat]}}>{cat === 'c3_z518' ? 'C3 (L)' : cat}</label>
                    <input type="number" min="0" className="w-full p-1.5 border rounded bg-slate-50 text-center font-bold text-sm" value={editModal[cat]} onChange={e => setEditModal({...editModal, [cat]: e.target.value})} />
                  </div>
                ))}
              </div>
              <button onClick={saveEditedTurno} className="w-full bg-emerald-500 text-white font-bold py-3.5 rounded-xl hover:bg-emerald-600 transition-all mt-4 flex justify-center items-center gap-2 text-sm shadow-md shadow-emerald-500/20"><Save className="w-4 h-4"/> Guardar Cambios</button>
            </div>
          </div>
        </div>
      )}

      {/* COLUMNA DERECHA: CANVAS DE SCROLL CONTINUO */}
      <main className="flex-1 h-full overflow-y-auto p-8 space-y-6 relative">
        {notification && (
          <div className={`fixed top-4 right-4 p-4 rounded-lg shadow-lg text-sm font-medium z-50 animate-bounce-in ${notification.type === 'error' ? 'bg-red-600 text-white' : notification.type === 'warning' ? 'bg-orange-500 text-white' : 'bg-emerald-600 text-white'}`}>
            {notification.msg}
          </div>
        )}

        {activeTab === 'resumen' && (
          <>
            {statsKPI && <PanelKPIs statsKPI={statsKPI} />}
            
            <FiltrosGlobales 
          modoComparativo={modoComparativo} setModoComparativo={setModoComparativo}
          filtroFechaInicio={filtroFechaInicio} setFiltroFechaInicio={setFiltroFechaInicio}
          filtroFechaFin={filtroFechaFin} setFiltroFechaFin={setFiltroFechaFin}
          filtroFechaInicioB={filtroFechaInicioB} setFiltroFechaInicioB={setFiltroFechaInicioB}
          filtroFechaFinB={filtroFechaFinB} setFiltroFechaFinB={setFiltroFechaFinB}
          applyDatePreset={applyDatePreset}
        />

          <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-4 mb-6 flex flex-col md:flex-row justify-between items-center gap-4 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-50 rounded-full blur-3xl -z-10 opacity-60 translate-x-20 -translate-y-20"></div>
            
            <div className="flex flex-wrap items-center gap-3 w-full">
              <div className="flex items-center gap-2 bg-indigo-50/80 px-3 py-1.5 rounded-lg border border-indigo-100 mr-2">
                <Filter className="w-4 h-4 text-indigo-600" />
                <span className="text-[11px] font-bold text-indigo-900 uppercase">Filtros Globales:</span>
              </div>
              
              <select value={filtrosGlobales.sexo} onChange={e => setFiltrosGlobales({...filtrosGlobales, sexo: e.target.value})} className="text-xs bg-white border border-slate-200 rounded-lg p-1.5 focus:border-indigo-500 font-medium text-slate-700">
                <option value="TODOS">Sexo: Todos</option>
                <option value="M">Hombres</option>
                <option value="F">Mujeres</option>
              </select>

              <select value={filtrosGlobales.edad} onChange={e => setFiltrosGlobales({...filtrosGlobales, edad: e.target.value})} className="text-xs bg-white border border-slate-200 rounded-lg p-1.5 focus:border-indigo-500 font-medium text-slate-700">
                <option value="TODOS">Edad: Todos</option>
                <option value="0-14">0 - 14 años</option>
                <option value="15-29">15 - 29 años</option>
                <option value="30-59">30 - 59 años</option>
                <option value="60+">60+ años</option>
              </select>

              <select value={filtrosGlobales.prevision} onChange={e => setFiltrosGlobales({...filtrosGlobales, prevision: e.target.value})} className="text-xs bg-white border border-slate-200 rounded-lg p-1.5 focus:border-indigo-500 font-medium text-slate-700">
                <option value="TODOS">Previsión: Todas</option>
                <option value="FONASA">FONASA</option>
                <option value="ISAPRE">ISAPRE</option>
              </select>
              
              <select value={filtrosGlobales.establecimiento} onChange={e => setFiltrosGlobales({...filtrosGlobales, establecimiento: e.target.value})} className="text-xs bg-white border border-slate-200 rounded-lg p-1.5 focus:border-indigo-500 font-medium text-slate-700">
                <option value="TODOS">Centro: Todos</option>
                <option value="FLORENCIA">CESFAM Florencia</option>
                <option value="BORIS">CESFAM Boris</option>
                <option value="ELGUETA">CESFAM Elgueta</option>
                <option value="OTROS">Otros Centros</option>
              </select>
              
              {Object.values(filtrosGlobales).some(v => v !== 'TODOS') && (
                <button onClick={() => setFiltrosGlobales({ sexo: 'TODOS', prevision: 'TODOS', edad: 'TODOS', establecimiento: 'TODOS' })} className="ml-auto text-[10px] bg-red-50 text-red-600 hover:bg-red-100 px-2 py-1 rounded font-bold transition-colors flex items-center gap-1">
                  <Eraser className="w-3 h-3"/> Limpiar Filtros
                </button>
              )}
            </div>
            {Object.values(filtrosGlobales).some(v => v !== 'TODOS') && (
              <div className="w-full mt-2 text-[10px] text-amber-600 bg-amber-50 p-1.5 rounded border border-amber-100 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5" /> Al usar Filtros Globales, los turnos ingresados manualmente (sin pacientes) son excluidos temporalmente del análisis.
              </div>
            )}
          </div>

        <GraficoDinamico 
          chartData={chartData} compareChartData={compareChartData} pieData={pieData}
          tipoGrafico={tipoGrafico} setTipoGrafico={setTipoGrafico}
          metricasGrafico={metricasGrafico} setMetricasGrafico={setMetricasGrafico}
          filtroVariables={filtroVariables} setFiltroVariables={setFiltroVariables}
          modoComparativo={modoComparativo} dynamicMetricKeys={dynamicMetricKeys}
          turnosFiltrados={turnosFiltrados}
        />

        <AnalisisEquiposTurno turnosFiltrados={turnosFiltrados} pacientesFiltrados={pacientesFiltrados} />

        {demografiaStats && (
          <>
            <AnalisisSociodemografico 
              demografiaStats={demografiaStats} 
              rankingCentros={rankingCentros} 
            />
            <MatrizCruzada pacientesFiltrados={pacientesFiltrados} />
          </>
        )}

        <TablaTiemposEspera 
          metricsByCategory={metricsByCategory} 
          promediosGlobales={promediosGlobales} 
        />

        <CurvaDemanda 
          peakHoursData={peakHoursData}
          demandaFechaInicio={demandaFechaInicio} setDemandaFechaInicio={setDemandaFechaInicio}
          demandaFechaFin={demandaFechaFin} setDemandaFechaFin={setDemandaFechaFin}
          demandaViewMode={demandaViewMode} setDemandaViewMode={setDemandaViewMode}
          modoComparativo={modoComparativo} docsToCompare={docsToCompare}
        />

        <AnalisisProfesionales 
          profFechaInicio={profFechaInicio} setProfFechaInicio={setProfFechaInicio}
          profFechaFin={profFechaFin} setProfFechaFin={setProfFechaFin}
          searchDoctor={searchDoctor} setSearchDoctor={setSearchDoctor}
          docsToCompare={docsToCompare} toggleDocToCompare={toggleDocToCompare}
          clearDocComparison={clearDocComparison}
          filteredMetricsByDoctor={filteredMetricsByDoctor}
          dailyDoctorData={dailyDoctorData}
        />

        <RankingProfesionales
          profFechaInicio={profFechaInicio} setProfFechaInicio={setProfFechaInicio}
          profFechaFin={profFechaFin} setProfFechaFin={setProfFechaFin}
          filteredMetricsByDoctor={filteredMetricsByDoctor}
        />

        <DataGridTurnos 
          turnosPaginados={turnosPaginados} turnosDB={turnosDB}
          paginaTurnos={paginaTurnos} setPaginaTurnos={setPaginaTurnos}
          totalPaginasTurnos={totalPaginasTurnos}
          setEditModal={setEditModal} setDeleteConfirm={setDeleteConfirm}
          userProfile={userProfile}
        />
          </>
        )}

        {activeTab === 'reportes' && (
          <ReportesModule pacientesDB={pacientesDB} turnosDB={turnosDB} />
        )}

        {activeTab === 'data' && (
          <GestionDatos 
            user={user} 
            db={db} 
            appId={appId} 
            loading={loading}
            setLoading={setLoading} 
            setSyncStatus={setSyncStatus} 
            showNotif={showNotif} 
            setActiveTab={setActiveTab} 
            setFiltroFechaInicio={setFiltroFechaInicio} 
            setFiltroFechaFin={setFiltroFechaFin} 
            centroActivo={centroActivo}
          />
        )}

        {activeTab === 'auditoria' && (
          <AuditLog db={db} appId={appId} centroActivo={centroActivo} />
        )}
      </main>
    </div>
  );
}

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-red-50 flex items-center justify-center p-8 font-sans">
          <div className="bg-white p-8 rounded-xl shadow-xl max-w-2xl border border-red-200">
            <div className="flex items-center gap-3 text-red-600 mb-4">
              <AlertTriangle className="w-8 h-8" />
              <h1 className="text-xl font-black">Error crítico en el panel</h1>
            </div>
            <p className="text-gray-600 mb-4 text-sm">React ha bloqueado la página por seguridad debido al siguiente error visual:</p>
            <div className="bg-gray-100 p-4 rounded text-xs font-mono text-gray-800 overflow-auto whitespace-pre-wrap max-h-64">
              {String(this.state.error)}
            </div>
            <button onClick={() => window.location.reload()} className="mt-6 bg-red-600 text-white px-6 py-2 rounded font-bold hover:bg-red-700 transition">Recargar Sistema</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function Dashboard() {
  return (
    <ErrorBoundary>
      <DashboardContent />
    </ErrorBoundary>
  );
}
