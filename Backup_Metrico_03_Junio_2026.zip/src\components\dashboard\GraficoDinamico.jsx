import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell, 
  Line, ResponsiveContainer, CartesianGrid, ComposedChart 
} from 'recharts';
import { BarChart2, CheckCircle, TrendingUp, BarChart as BarChartIcon, PieChart as PieChartIcon, Search, HelpCircle, X } from 'lucide-react';
import { COLORS, METRIC_LABELS } from '../../config/constants';

export default function GraficoDinamico({
  modoComparativo,
  tipoGrafico,
  setTipoGrafico,
  filtroVariables,
  setFiltroVariables,
  metricasGrafico,
  setMetricasGrafico,
  dynamicMetricKeys,
  compareChartData,
  chartData,
  pieData,
  turnosFiltrados
}) {
  const [showHelpModal, setShowHelpModal] = React.useState(false);

  const getColorForMetric = (metricKey) => {
      if (METRIC_LABELS[metricKey]) return COLORS[metricKey] || '#94a3b8';
      for (const group in dynamicMetricKeys) {
        const found = dynamicMetricKeys[group].find(m => m.value === metricKey);
        if (found) return found.color;
      }
      return '#cbd5e1';
  };

  const formatMetricName = (metricKey) => {
      if (METRIC_LABELS[metricKey]) return METRIC_LABELS[metricKey];
      for (const group in dynamicMetricKeys) {
        const found = dynamicMetricKeys[group].find(m => m.value === metricKey);
        if (found) return found.label;
      }
      return metricKey;
  };

  const handleGraphToggleChange = (metricValue) => {
    setMetricasGrafico(prev => {
      if (prev.includes(metricValue)) return prev.filter(m => m !== metricValue);
      return [...prev, metricValue];
    });
  };

  const renderCheckbox = (metric) => (
    <label key={metric.value} className="flex items-center gap-2 cursor-pointer text-xs group">
      <div className="relative flex items-center justify-center">
        <input 
          type="checkbox" 
          checked={metricasGrafico.includes(metric.value)}
          onChange={() => handleGraphToggleChange(metric.value)}
          className="sr-only"
        />
        <div className={`w-4 h-4 rounded transition border ${metricasGrafico.includes(metric.value) ? 'border-transparent' : 'border-slate-300 group-hover:border-slate-400'}`} style={{ backgroundColor: metricasGrafico.includes(metric.value) ? metric.color : 'transparent' }}>
          {metricasGrafico.includes(metric.value) && <CheckCircle className="w-3.5 h-3.5 text-white absolute top-0.5 left-0.5" />}
        </div>
      </div>
      <span className={metricasGrafico.includes(metric.value) ? 'font-bold text-slate-700' : 'text-slate-500'}>{metric.label}</span>
    </label>
  );

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-base font-bold text-slate-800 flex items-center gap-2"><BarChart2 className="text-blue-500 w-5 h-5"/> Análisis Visual Dinámico Total</h2>
        {!modoComparativo ? (
          <div className="flex gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
            <button onClick={() => setTipoGrafico('compuesto')} className={`p-1.5 rounded ${tipoGrafico === 'compuesto' ? 'bg-white shadow-sm' : 'text-slate-400'}`} title="Gráfico Compuesto"><TrendingUp className="w-4 h-4"/></button>
            <button onClick={() => setTipoGrafico('barras')} className={`p-1.5 rounded ${tipoGrafico === 'barras' ? 'bg-white shadow-sm' : 'text-slate-400'}`} title="Gráfico de Barras"><BarChartIcon className="w-4 h-4"/></button>
            <button onClick={() => setTipoGrafico('torta')} className={`p-1.5 rounded ${tipoGrafico === 'torta' ? 'bg-white shadow-sm' : 'text-slate-400'}`} title="Gráfico Circular"><PieChartIcon className="w-4 h-4"/></button>
          </div>
        ) : null}
      </div>

      {/* Controles estilo Acordeón */}
      {(!modoComparativo && (tipoGrafico === 'compuesto' || tipoGrafico === 'barras')) || modoComparativo ? (
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-4 mb-6">
          <div className="flex justify-between items-center mb-4">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Control de Variables del Gráfico</span>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2 top-2 text-slate-400" />
                <input type="text" placeholder="Buscar variables..." value={filtroVariables} onChange={e => setFiltroVariables(e.target.value)} className="text-[11px] pl-7 p-1.5 px-3 rounded-full border border-slate-200 w-64 bg-white focus:outline-none"/>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-start">
             <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col h-56">
               <div className="bg-slate-100 border-b border-slate-200 font-bold text-[11px] p-2 text-slate-700 flex items-center gap-1.5 sticky top-0"><span className="w-1.5 h-1.5 rounded-full bg-blue-500 block"></span> Operacional & Tiempos</div>
               <div className="p-2 flex flex-col gap-1.5 overflow-y-auto flex-1">{Object.entries(METRIC_LABELS).map(([k, label]) => renderCheckbox({ value: k, label: label, color: COLORS[k] || '#94a3b8' }))}</div>
             </div>

             <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col h-56">
               <div className="bg-slate-100 border-b border-slate-200 font-bold text-[11px] p-2 text-slate-700 flex items-center gap-1.5 sticky top-0"><span className="w-1.5 h-1.5 rounded-full bg-pink-500 block"></span> Sexo y Edad</div>
               <div className="p-2 flex flex-col gap-1.5 overflow-y-auto flex-1">{dynamicMetricKeys.sexo.map(renderCheckbox)}{dynamicMetricKeys.edad.map(renderCheckbox)}</div>
             </div>

             <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col h-56">
               <div className="bg-slate-100 border-b border-slate-200 font-bold text-[11px] p-2 text-slate-700 flex items-center gap-1.5 sticky top-0"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 block"></span> Previsión</div>
               <div className="p-2 flex flex-col gap-1.5 overflow-y-auto flex-1">{dynamicMetricKeys.prev.map(renderCheckbox)}</div>
             </div>

             <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col h-56">
               <div className="bg-slate-100 border-b border-slate-200 font-bold text-[11px] p-2 text-slate-700 flex items-center gap-1.5 sticky top-0"><span className="w-1.5 h-1.5 rounded-full bg-orange-500 block"></span> Origen y Nacionalidad</div>
               <div className="p-2 flex flex-col gap-1.5 overflow-y-auto flex-1">{dynamicMetricKeys.com.map(renderCheckbox)}{dynamicMetricKeys.nac.map(renderCheckbox)}</div>
             </div>

             <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden flex flex-col h-56">
               <div className="bg-slate-100 border-b border-slate-200 font-bold text-[11px] p-2 text-slate-700 flex items-center gap-1.5 sticky top-0"><span className="w-1.5 h-1.5 rounded-full bg-purple-500 block"></span> Establecimientos</div>
               <div className="p-2 flex flex-col gap-1.5 overflow-y-auto flex-1">{dynamicMetricKeys.est.map(renderCheckbox)}</div>
             </div>
          </div>
        </div>
      ) : null}

      <div className="h-80 w-full mt-4">
        {modoComparativo && metricasGrafico.length > 0 ? (
          <ResponsiveContainer>
            <BarChart data={compareChartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
              <YAxis fontSize={10} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
              <Legend />
              <Bar dataKey="Periodo A" fill="#6366f1" radius={[4,4,0,0]} name="Periodo A" barSize={30} />
              <Bar dataKey="Periodo B" fill="#fbbf24" radius={[4,4,0,0]} name="Periodo B" barSize={30} />
            </BarChart>
          </ResponsiveContainer>
        ) : null}

        {!modoComparativo && tipoGrafico === 'barras' && chartData.length > 0 ? (
          <ResponsiveContainer>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
              <YAxis fontSize={10} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
              <Legend wrapperStyle={{fontSize: '11px'}} />
              {metricasGrafico.map(m => (
                <Bar key={m} dataKey={m} fill={getColorForMetric(m)} name={formatMetricName(m)} radius={[4,4,0,0]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        ) : null}

        {!modoComparativo && tipoGrafico === 'compuesto' && chartData.length > 0 ? (
          <ResponsiveContainer>
            <ComposedChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" fontSize={10} tickMargin={10} axisLine={false} tickLine={false} />
              <YAxis yAxisId="left" fontSize={10} axisLine={false} tickLine={false} />
              <YAxis yAxisId="right" orientation="right" fontSize={10} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
              <Legend wrapperStyle={{fontSize: '11px'}} />
              
              {metricasGrafico.map(m => {
                if (!m) return null;
                const isTime = m.startsWith('tiempo');
                return (
                  <Line 
                    key={m} 
                    yAxisId={isTime ? "right" : "left"} 
                    type="monotone" 
                    dataKey={m} 
                    name={formatMetricName(m)} 
                    stroke={getColorForMetric(m)} 
                    strokeWidth={isTime ? 2 : 3} 
                    strokeDasharray={isTime ? "5 5" : undefined} 
                    dot={{ r: 3 }} 
                    activeDot={{ r: 5 }} 
                  />
                );
              })}
            </ComposedChart>
          </ResponsiveContainer>
        ) : null}

        {!modoComparativo && tipoGrafico === 'torta' && pieData.length > 0 ? (
          <ResponsiveContainer>
            <PieChart margin={{ top: 20, right: 30, left: 30, bottom: 20 }}>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={60} outerRadius={90} paddingAngle={5} dataKey="value" label={({name, percent}) => percent > 0.01 ? `${name} ${(percent * 100).toFixed(0)}%` : ''} labelLine={true}>
                {pieData.map((entry, index) => {
                   const colorKey = entry.name === 'C3 (Lesiones)' ? 'c3_z518' : entry.name.toLowerCase();
                   return <Cell key={`cell-${index}`} fill={COLORS[colorKey]} />
                })}
              </Pie>
              <Tooltip contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
              <Legend verticalAlign="bottom" height={36} wrapperStyle={{fontSize: '11px'}}/>
            </PieChart>
          </ResponsiveContainer>
        ) : null}
        
        
        {turnosFiltrados.length === 0 ? <div className="h-full flex items-center justify-center text-slate-400 text-sm">Sin datos para graficar</div> : null}
      </div>
    </div>
  );
}
